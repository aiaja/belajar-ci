<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Produk
<?= $this->endSection() ?>
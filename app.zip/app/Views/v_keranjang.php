<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Keranjang
<?= $this->endSection() ?>
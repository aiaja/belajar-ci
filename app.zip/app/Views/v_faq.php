<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
F.A.Q.
<?= $this->endSection() ?>